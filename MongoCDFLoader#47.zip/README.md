# Mongo CDF Loader

[![Build Status](https://feddtwdevops.ncodefederal.dev/jenkins/buildStatus/icon?job=VePRO+Task+3%2FMongoCDFLoader)](https://feddtwdevops.ncodefederal.dev/jenkins/job/VePRO%20Task%203/job/MongoCDFLoader/)
[![Pure Kotlin](https://img.shields.io/badge/100%25-kotlin-blue.svg)](https://kotlinlang.org/)

Mongo CDF Loader serializes [NASA Common Data Format (CDF)](https://cdf.gsfc.nasa.gov/) files then loads them into a [MongoDB](https://www.mongodb.com/) store.

It is written in [Kotlin](https://kotlinlang.org/) and targets the Java Virtual Machine. This allows it to run on any platform that Java is supported.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

A [Java](https://www.java.com/en/) JRE or SDK is the only prerequisite for Mongo CDF Loader. Installation of Java depends on your operating system and will not be covered in this README. The latest LTS (long-term support) release of [AdoptOpenJDK](https://adoptopenjdk.net/) is recommended on Windows.

To ensure that Java is installed, open a console and type `java -version`. This should return information about the Java installation on your system:

```bash
openjdk version "11.0.4" 2019-07-16
OpenJDK Runtime Environment AdoptOpenJDK (build 11.0.4+11)
OpenJDK 64-Bit Server VM AdoptOpenJDK (build 11.0.4+11, mixed mode)
```

### Building

Mongo CDF Loader uses the [Gradle Build Tool](https://kotlinlang.org/). To build, open a console in the root of the project and execute:

```bash
./gradlew shadowJar
```

This will create an executable JAR containing all dependencies in `build/libs`.

## Usage

MongoCDFLoader has highly descriptive help text and useful command line options:

```text
Usage: MongoCDFLoader ([CDFs...] | [-k=<kafkaServer> -T=<timeout> [-t=<topic>]
                      [-g=<groupID>] [-o=<offset>]]) [-hV] [-c=<configFile>]
                      [-l=<channelsListFile>]
Serializes and loads CDF files into MongoDB
  -c, --config-file=<configFile>
                             Path to database configuration properties file,
                               includes connection options and customization
                               Default: config.properties
  -l, --channels-list=<channelsListFile>
                             Path to a file containing a list of channel names
                               (case-insensitive) to be loaded, one per line.
                               If this option is not specified, or the file is
                               empty, all channels will be loaded.
  -h, --help                 Show this help message and exit.
  -V, --version              Print version information and exit.
Standalone Mode
*     CDFs...                CDF file(s) or directories (will be searched
                               recursively) containing CDFs. Wildcards (*, ?)
                               are accepted for file names but not directory
                               names. Both relative and absolute paths are
                               accepted.
Kafka Consumer Mode
* -k, --kafka-server=<kafkaServer>
                             Hostname and port of Apache Kafka server
* -T, --timeout=<timeout>    Seconds to wait before killing this consumer if no
                               messages have been received. Set to 0 to never
                               timeout.
  -t, --kafka-topic=<topic>  Apache Kafka topic to consume paths to CDF files
                               from.
                               Default: FilesToLoad
  -g, --group-id=<groupID>   Apache Kafka consumer group ID. If this option is
                               not specified, a random consumer group ID will
                               be assigned.
  -o, --offset=<offset>      Kafka auto offset reset configuration. Options are
                               earliest, latest and none.
                               Default: earliest
Copyright© 2019 HBM nCode Federal LLC
```

### Using a Properties File for Command Line Options

Any of these command line options can also be passed in as a properties file. This properties file, by default, is named `.MongoCDFLoader.properties` (note the `.` at the beginning of the file name), and is located in your home directory (`/home/<user>` on *nix or `C:\Users\<user>` on Windows by default). The path of this file can be changed by setting the full path to the properties file as the `picocli.defaults.MongoCDFLoader.path` system property.

This file must be in the standard [Java `.properties` file format](https://docs.oracle.com/javase/tutorial/essential/environment/properties.html).

For the options above, the key is the option's longest name, without the prefix. So, for option `--timeout`, the key would be `timeout`. The following is an example properties file that sets the value for `timeout` and `kafka-topic`:

```properties
timeout=30
kafka-topic=FilesToLoad
```

**Note that the properties file mentioned in this section can, but does not have to be, the same file specified with the `--config-file` option**

### Using Variables for Command Line Options

Another way of specifying command line options is to set them as variables on your system. The following types of variables are supported:

* [System properties](https://docs.oracle.com/javase/tutorial/essential/environment/sysprop.html)
* [Environment variables](https://en.wikipedia.org/wiki/Environment_variable)
* [Java Resource bundle](https://docs.oracle.com/javase/8/docs/api/java/util/ResourceBundle.html)

For the options above, the variable name is `MongoCDFLoader.` followed by the option's longest name, without the prefix. So, for option `--timeout`, the variable name would be `MongoCDFLoader.timeout`.

## License

Copyright (c) HBM nCode Federal LLC. All rights reserved.

Licensed under the [HBM nCode Federal LLC Software Licensing Agreement](LICENSE.md).
